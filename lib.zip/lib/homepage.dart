import 'dart:convert';
import 'dart:convert' as convert;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_project/request.dart';
import 'package:http/http.dart' as http;

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  var _summary = "";
  var isLoading = false;
  @override
  void initState() {
    super.initState();
  }
  Future<void> _incrementCounter() async {

    // var url = Uri.parse('https://summarisation-api-project.azurewebsites.net/');
    // var url = Uri.parse('http://127.0.0.1:5000/hello');
    var url = Uri.parse('http://127.0.0.1:5000/summarise/yoyo');
    // Await the http get response, then decode the json-formatted response.
    // var response = await getData(url);
    // if (response.statusCode == 200) {
    //   var jsonResponse =
    //   convert.jsonDecode(response.body) as Map<String, dynamic>;
    //   var query = jsonResponse['query'];
    //   print('Query: $query.');
    // } else {
    //   print('Request failed with status: ${response.statusCode}.');
    // }

    var  result;
    var responseString = await getResponse(url); //.then((value) => value);
    print("Response string");
    print(responseString.runtimeType);
    // print(value);

    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    final myController = TextEditingController();

    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            // Here we take the value from the MyHomePage object that was created by
            // the App.build method, and use it to set our appbar title.
            title: Text(widget.title),
          ),
          body: Center(
            // Center is a layout widget. It takes a single child and positions it
            // in the middle of the parent.
              child: Container(
                  child: Expanded(
                      child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                                flex:2,
                                child:Column(
                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Enter your text here",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),
                                    Expanded(child:
                                    Container(
                                        color: Colors.white,
                                        child:
                                        TextFormField(
                                          controller: myController,
                                          // minLines: 10,
                                          keyboardType: TextInputType.multiline,
                                          maxLines: null,
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            labelText: 'Text',
                                            contentPadding: EdgeInsets.all(15.0),
                                          ),

                                        )
                                    )),
                                    Container(
                                        width: MediaQuery.of(context).size.width/3,

                                        // margin: const EdgeInsets.only(left: 20.0, right: 20.0, top:  0, bottom: 20),
                                        child:

                                        isLoading ?  Center(child:CircularProgressIndicator()) :
                                        ElevatedButton(
                                          child: Text('Summarise'),
                                          onPressed: () async {
                                            print("loading");
                                            setState((){
                                              isLoading=true;
                                            });
                                            var url = Uri.parse('http://127.0.0.1:5000/summarise/' + myController.text);
                                            var response = await getResponse(url);
                                            // getResponse(url).then((value)=> {
                                            // print("PRINTING VALUE"+ value)
                                            setState(()
                                            {
                                              print("Done");
                                              isLoading=false;
                                              print(response);
                                              _summary = response;
                                            });
                                            //   setState((){
                                            //   isLoading=false;
                                            //   })
                                            // });
                                          },
                                        )
                                      // FloatingActionButton(
                                      //   // When the user presses the button, show an alert dialog containing the
                                      //   // text that the user has entered into the text field.
                                      //   onPressed: () {
                                      //     print("PRESSED!");
                                      //     var url = Uri.parse('http://127.0.0.1:5000/summarise/' + myController.text);
                                      //     FutureBuilder(
                                      //         future: getResponse(url),
                                      //         builder: (context, snapshot) {
                                      //           print("BUILDING");
                                      //           print(snapshot.connectionState);
                                      //           if(snapshot.connectionState != ConnectionState.done) {
                                      //             print("STATE NOT DONE");
                                      //             // return Text("Done");
                                      //                 // return snapshot.data;
                                      //           } else if (snapshot.connectionState == ConnectionState.done){
                                      //             setState(()
                                      //             {
                                      //               print("printing value");
                                      //               print(snapshot.data);
                                      //               // _summary = snapshot.data;
                                      //             });
                                      //           } else if(snapshot.hasError){
                                      //             // return Text("Something went wrong!");
                                      //           } else {
                                      //               print("Progressing");
                                      //               return CircularProgressIndicator();
                                      //           }
                                      //           return Text("BUILDER");
                                      //         }
                                      //     );
                                      //   //
                                      //   //
                                      //     getResponse(url).then((value)=> {
                                      //       // print("PRINTING VALUE"+ value)
                                      //         setState(()
                                      //          {
                                      //            print("printing value");
                                      //            print(value);
                                      //         _summary = value;
                                      //         })
                                      //     });
                                      //   // },
                                      //   // tooltip: 'Summarise!',
                                      //   // child: Column(
                                      //   //   children: [
                                      //   //     Container(
                                      //   //       child:
                                      //   //     Text(
                                      //   //       ""
                                      //   //     )),
                                      //   //     Container(
                                      //   //       child:
                                      //   //       Icon(Icons.done)
                                      //   //     )
                                      //   //   ],
                                      //   // ),
                                      // )
                                    ),
                                  ],
                                )),
                            Expanded(
                                flex:3,
                                child:Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Summary",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),
                                    Expanded(child:Container(
                                      color: Colors.white10,
                                      child: Container(margin: const EdgeInsets.only(left: 10.0, right: 10.0, top:  10, bottom: 10),
                                          child:
                                          EditableText(
                                            autofocus: true,
                                            maxLines: null,
                                            backgroundCursorColor: Colors.amber,
                                            cursorColor: Colors.green,
                                            style: TextStyle(),
                                            focusNode:  FocusNode(),
                                            controller: myController,
                                            onSubmitted: (val) {
                                              // _addCard(val);
                                              Navigator.pop(context);
                                            },
                                          )
                                        // SelectableText(_summary,
                                        // toolbarOptions: ToolbarOptions(copy:true, cut:true, paste:true, selectAll: true),)
                                      ),
                                    )),
                                  ],
                                )),
                            Expanded(
                                flex:3,
                                child:Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,

                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Keywords",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),

                                    Expanded(child:Container(
                                      // margin: const EdgeInsets.only(left: 10.0, right: 10.0, top:  15, bottom: 10),
                                      color: Colors.white,
                                      child: Container(margin: const EdgeInsets.only(left: 10.0, right: 10.0, top:  10, bottom: 10),
                                          child:Text("...")),
                                    )),

                                  ],
                                )),
                          ]
                      ))
              )
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: _incrementCounter,
            tooltip: 'Increment',
            child: Icon(Icons.add),
          ), // This trailing comma makes auto-formatting nicer for build methods.
        ));
  }
}

// Define a custom Form widget.
class MyCustomForm extends StatefulWidget {
  @override
  _MyCustomFormState createState() => _MyCustomFormState();
}

// Define a corresponding State class.
// This class holds the data related to the Form.
class _MyCustomFormState extends State<MyCustomForm> {
  // Create a text controller and use it to retrieve the current value
  // of the TextField.
  final myController = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    myController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
    // Fill this out in the next step.
  }
}