import 'dart:convert';
import 'dart:convert' as convert;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_project/request.dart';
import 'package:http/http.dart' as http;
import 'package:json_table/json_table.dart';
import 'dart:convert' show utf8;

// {"Text1":{"0":"Its life can be extended for one year at a time during a national emergency. During the 13th Lok Sabha, Bhartiya Janata Party lost a no-confidence motion by one vote and had to resign.","1":"The Lok Sabha is elected for a term of five years. It can be dissolved earlier than its term by the President on the advice of the Prime Minister. It can be voted out of power by a debate and vote on a no-confidence motion.","2":"The House may have not more than 552 members; 530 elected from the states, 20 from Union Territories and not more than 2 members nominated from the Anglo-Indian Community. At present, the strength of the Lok Sabha is 545."},
// "Text2":{"0":"It cannot be dissolved. The total strength of the Rajya Sabha cannot be more than 250 \nof which 238 are elected while 12 arc nominated by the President of India.","1":"However, each member of the Rajya Sabha enjoys a six-year tcrm. Every \ntwo years one-third of its members retire by rotation.","2":"The Rajya Sabha is a permanent House. When the Lok Sabha is not in session or is \ndissolved, the permanent house still functions."}}


class TablesPage extends StatefulWidget {
  TablesPage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _TablesPageState createState() => _TablesPageState();
}

class _TablesPageState extends State<TablesPage> {
  int _counter = 0;
  var _table_data;
  var isLoading = false;
  @override
  void initState() {
    super.initState();
  }

  getTexts(obj) {
    var result = [];
    for(var i = 0; i< obj["Text1"].length; i++) {
      result.add(Text(obj["Text1"][i]));
      result.add(Text(obj["Text2"][i]));
    }
    return result;
  }

  Future<void> _incrementCounter() async {

    // var url = Uri.parse('https://summarisation-api-project.azurewebsites.net/');
    // var url = Uri.parse('http://127.0.0.1:5000/hello');
    var url = Uri.parse('http://127.0.0.1:5000/summarise/yoyo');
    // Await the http get response, then decode the json-formatted response.
    // var response = await getData(url);
    // if (response.statusCode == 200) {
    //   var jsonResponse =
    //   convert.jsonDecode(response.body) as Map<String, dynamic>;
    //   var query = jsonResponse['query'];
    //   print('Query: $query.');
    // } else {
    //   print('Request failed with status: ${response.statusCode}.');
    // }

    var  result;
    var responseString = await getResponse(url); //.then((value) => value);
    print("Response string");
    print(responseString.runtimeType);
    // print(value);

    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    final text1controller = TextEditingController();
    final text2controller = TextEditingController();

    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return SafeArea(
        child: Scaffold(
          appBar: AppBar(
            // Here we take the value from the MyHomePage object that was created by
            // the App.build method, and use it to set our appbar title.
            title: Text(widget.title),
          ),
          body: Center(
            // Center is a layout widget. It takes a single child and positions it
            // in the middle of the parent.
              child: Container(
                  child: Expanded(
                      child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                                flex:2,
                                child:Column(
                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Text 1",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),
                                    Expanded(child:
                                    Container(
                                        color: Colors.white,
                                        child:
                                        TextFormField(
                                          controller: text1controller,
                                          // minLines: 10,
                                          keyboardType: TextInputType.multiline,
                                          maxLines: null,
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            labelText: 'Text',
                                            contentPadding: EdgeInsets.all(15.0),
                                          ),

                                        )
                                    )),
                                  ],
                                )),
                            Expanded(
                                flex:2,
                                child:Column(
                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Text 2",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),
                                    Expanded(child:
                                    Container(
                                        color: Colors.white,
                                        child:
                                        TextFormField(
                                          controller: text2controller,
                                          // minLines: 10,
                                          keyboardType: TextInputType.multiline,
                                          maxLines: null,
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            labelText: 'Text',
                                            contentPadding: EdgeInsets.all(15.0),
                                          ),

                                        )
                                    )),
                                    Container(
                                        width: MediaQuery.of(context).size.width/3,

                                        // margin: const EdgeInsets.only(left: 20.0, right: 20.0, top:  0, bottom: 20),
                                        child:

                                        isLoading ?  Center(child:CircularProgressIndicator()) :
                                        ElevatedButton(
                                          child: Text('Tabulate'),
                                          onPressed: () async {
                                            print("loading");
                                            setState((){
                                              isLoading=true;
                                            });
                                            var url = Uri.parse('http://127.0.0.1:5000/tabulate/' + text1controller.text.replaceAll("\/", "%20or%20").replaceAll("\n", "") + "/" + text2controller.text.replaceAll("\/", "%20or%20").replaceAll("\n", ""));
                                            var jsonResponse = await getResponseJson(url);
                                            setState(()
                                            {
                                              print("Done");
                                              isLoading=false;
                                              print(jsonResponse);
                                              print(jsonResponse.runtimeType);
                                              _table_data = jsonResponse;
                                            });
                                          },
                                        )
                                    ),
                                  ],
                                )),
                            Expanded(
                                flex:3,
                                child:Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,

                                  children: [
                                    Container(
                                        height: 35,
                                        decoration: BoxDecoration(
                                          color: Colors.blueAccent,
                                        ),
                                        child:Center(
                                            child:Text(
                                              "Table",
                                              textAlign: TextAlign.center,
                                            ))
                                    ),

                                    Expanded(child:Container(
                                      // margin: const EdgeInsets.only(left: 10.0, right: 10.0, top:  15, bottom: 10),
                                      color: Colors.white,
                                      child: Container(margin: const EdgeInsets.only(left: 10.0, right: 10.0, top:  10, bottom: 10),
                                          child: (_table_data != null )?
                                          JsonTable(_table_data) : Text("Data will appear here")
                                      ),
                                    )),

                                  ],
                                )),
                          ]
                      ))
              )
          ),
          floatingActionButton: FloatingActionButton(
            onPressed: _incrementCounter,
            tooltip: 'Increment',
            child: Icon(Icons.add),
          ), // This trailing comma makes auto-formatting nicer for build methods.
        ));
  }
}
